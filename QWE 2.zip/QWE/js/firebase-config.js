// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCuzVmums7pX0CQ6biv6DMknYIKv7kOPNw",
  authDomain: "hackathonproject-539bb.firebaseapp.com",
  projectId: "hackathonproject-539bb",
  storageBucket: "hackathonproject-539bb.firebasestorage.app",
  messagingSenderId: "691851621211",
  appId: "1:691851621211:web:67ba933983add4adfc607e",
  measurementId: "G-VCB3RKC891"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);