console.log('main.js loaded');
document.getElementById('year').textContent = new Date().getFullYear();

    let currentUser = null;



    // Initialize the page
    window.onload = () => {
      // Проверяем авторизацию и загружаем данные
      firebase.auth().onAuthStateChanged(async (user) => {
        if (user) {
          const doc = await firebase.firestore().collection("users").doc(user.uid).get();
          if (doc.exists) {
            currentUser = doc.data();
            currentUser.id = user.uid;
          }
        }
    
        updateAuthUI();
        renderProjects();
        renderProfiles();
        renderAnnouncements();

        setTimeout(() => {
          document.querySelectorAll('.project-card').forEach((card, index) => {
            card.classList.add('animate-fadeIn');
            card.style.animationDelay = `${index * 0.1}s`;
          });
    
          document.querySelectorAll('.profile-card').forEach((card, index) => {
            card.classList.add('animate-fadeIn');
            card.style.animationDelay = `${index * 0.1}s`;
          });
        }, 300);
      });
    };


    function renderProfiles() {
      const container = document.querySelector('#profiles .grid');
      container.innerHTML = '';
    
      firebase.firestore().collection('users').get()
        .then(snapshot => {
          const profiles = []; 
          snapshot.forEach(doc => {
            const profile = doc.data();
            profiles.push(profile); 
          });
    
          profiles.forEach(profile => {
            const isCurrentUser = currentUser && profile.username === currentUser.username;
    
            const card = document.createElement('div');
            card.className = 'card bg-white rounded-xl overflow-hidden shadow-md profile-card';
            card.innerHTML = `
              <div class="p-6 flex flex-col justify-between bg-white rounded-xl h-full">
                <div class="flex items-center mb-4">
                  <div class="w-16 h-16 rounded-full bg-primary bg-opacity-10 flex items-center justify-center text-primary text-2xl font-bold mr-4">
                    ${profile.name?.charAt(0) || "U"}
                  </div>
                  <div>
                    <h3 class="text-xl font-bold">${profile.name || profile.username}</h3>
                    <p class="text-gray-500">@${profile.username}</p>
                  </div>
                </div>
    
                ${profile.bio ? `<p class="text-gray-700 mb-4">${profile.bio}</p>` : ''}
    
                <div class="mb-4">
                  <p class="text-sm text-gray-500"><i class="fas fa-graduation-cap mr-2"></i> ${profile.faculty || 'Not specified'}, ${profile.year || 'Not specified'}</p>
                </div>
    
                ${isCurrentUser ? `
                  <button onclick="goToProfile()" class="w-full btn-primary text-white py-2 rounded-lg">
                    <i class="fas fa-edit mr-1"></i> Edit Profile
                  </button>
                ` : `
                  <button onclick="viewProfile('${profile.username}')" class="w-full bg-gray-100 text-gray-800 py-2 rounded-lg mt-auto">
                    <i class="fas fa-eye mr-1"></i> View Profile
                  </button>
                `}
              </div>
            `;
    
            container.appendChild(card);
          });
        })
        .catch(err => {
          console.error("Failed to load profiles:", err);
        });
    }
    

    function renderAnnouncements() {
      const container = document.querySelector('#announcements .space-y-4');
      container.innerHTML = '';
    
      firebase.firestore().collection("announcements").orderBy("createdAt", "desc").get()
        .then(snapshot => {
          snapshot.forEach(doc => {
            const announcement = doc.data();
            const isAuthor = currentUser && currentUser.id === announcement.authorId;
    
            const card = document.createElement('div');
            card.className = 'card bg-white rounded-xl overflow-hidden shadow-md animate-fadeIn';
            card.innerHTML = `
              <div class="p-6">
                <div class="flex justify-between items-start mb-2">
                  <h3 class="text-xl font-bold">${announcement.title}</h3>
                  ${isAuthor ? `
                    <button onclick="deleteAnnouncement('${doc.id}')" class="text-red-500 hover:text-red-700">
                      <i class="fas fa-trash"></i>
                    </button>
                  ` : ''}
                </div>
                <p class="text-gray-600 mb-4">${announcement.content}</p>
                <div class="flex justify-between items-center text-sm text-gray-500">
                  <span><i class="fas fa-user mr-1"></i> @${announcement.author}</span>
                  <span><i class="far fa-calendar mr-1"></i> ${new Date(announcement.createdAt?.toDate()).toLocaleDateString()}</span>
                </div>
              </div>
            `;
            container.appendChild(card);
          });
        });
    }

    function toggleProfileMenu() {
      document.getElementById('profile-menu').classList.toggle('hidden');
    }

    function openProfileModal() {
      if (!currentUser) return;
      
      document.getElementById('profile-username').value = currentUser.username;
      document.getElementById('profile-name').value = currentUser.name;
      document.getElementById('profile-email').value = currentUser.email;
      document.getElementById('profile-bio').value = currentUser.bio || '';
      document.getElementById('profile-faculty').value = currentUser.faculty || '';
      document.getElementById('profile-year').value = currentUser.year || '';
      
      document.getElementById('profile-modal').classList.remove('hidden');
      document.getElementById('profile-menu').classList.add('hidden');
    }

    function closeProfileModal() {
      document.getElementById('profile-modal').classList.add('hidden');
    }

    function saveProfile() {
      if (!currentUser) return;
      
      const username = document.getElementById('profile-username').value.trim();
      const name = document.getElementById('profile-name').value.trim();
      const email = document.getElementById('profile-email').value.trim();
      const bio = document.getElementById('profile-bio').value.trim();
      const faculty = document.getElementById('profile-faculty').value.trim();
      const year = document.getElementById('profile-year').value.trim();
      
      // Validate username length
      if (username.length < 8) {
        alert('Username must be at least 8 characters long.');
        return;
      }
      
      // Check if username is already taken by another user
      const usernameTaken = profiles.some(p => p.username === username && p.email !== currentUser.email);
      if (usernameTaken) {
        alert('This username is already taken by another user.');
        return;
      }
      
      // Update current user
      currentUser.username = username;
      currentUser.name = name;
      currentUser.email = email;
      currentUser.bio = bio;
      currentUser.faculty = faculty;
      currentUser.year = year;
      
      // Update in profiles array
      const index = profiles.findIndex(p => p.email === currentUser.email);
      if (index !== -1) {
        profiles[index] = currentUser;
      }
      
      updateAuthUI();
      renderProfiles();
      closeProfileModal();
    }

    function toggleCreateProject() {
      if (!currentUser) {
        alert('Please login to create a project.');
        toggleLogin();
        return;
      }
      document.getElementById('create-project').classList.toggle('hidden');
    }

    function submitProject() {
      const title = document.getElementById('project-title').value.trim();
      const category = document.getElementById('project-category').value.trim();
      const description = document.getElementById('project-description').value.trim();
      const tags = document.getElementById('project-tags').value.trim().split(',').map(tag => tag.trim());
      const type = document.getElementById('project-type').value;
    
      if (!title || !category || !description) {
        alert('Please fill in all required fields.');
        return;
      }
    
      const newProject = {
        title,
        category,
        description,
        tags,
        type,
        owner: currentUser.username,
        ownerId: currentUser.id,
        members: [],
        createdAt: firebase.firestore.FieldValue.serverTimestamp(),
        duration: "3 months",
        image: "default-project.jpg"
      };
    
      firebase.firestore().collection("projects").add(newProject)
        .then(() => {
          alert("Project created.");
          renderProjects();
          toggleCreateProject(); // скрыть форму
        })
        .catch(err => {
          console.error("Error adding project:", err);
          alert("Failed to create project.");
        });
    }
    function renderProjects() {
      const container = document.querySelector('#projects .grid');
      container.innerHTML = '';
    
      firebase.firestore().collection('projects').orderBy('createdAt', 'desc').get()
        .then(snapshot => {
          snapshot.forEach(doc => {
            const project = doc.data();
            const id = doc.id;
            const isOwner = currentUser && project.ownerId === currentUser.id;
            const isMember = currentUser && project.members.some(m => m.userId === currentUser.id);
    
            const card = document.createElement('div');
            card.className = 'card bg-white rounded-xl overflow-hidden shadow-md p-6 flex flex-col h-full project-card';
            card.innerHTML = `
              <h3 class="text-xl font-bold mb-2">${project.title}</h3>
              <p class="text-sm text-gray-500 mb-2">${project.category || ''}</p>
              <p class="text-gray-600 mb-4">${project.description}</p>
              <div class="flex flex-wrap gap-2 mb-4">
                ${project.tags.map(tag => `<span class="bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded">${tag}</span>`).join('')}
              </div>
              <p class="text-sm text-gray-400 mt-auto">${project.duration || ''}</p>
              ${isOwner ? `
                <div class="flex mt-4 space-x-2">
                  <button class="w-full bg-gray-200 text-gray-800 py-2 rounded-lg">Edit</button>
                  <button onclick="deleteProject('${id}')" class="w-full bg-red-100 text-red-600 py-2 rounded-lg">Delete</button>
                </div>
              ` : isMember ? `
                <button onclick="leaveProject('${id}')" class="mt-4 w-full bg-red-100 text-red-600 py-2 rounded-lg">Leave Project</button>
              ` : currentUser ? `
                <button onclick="joinProject('${id}')" class="mt-4 w-full btn-primary text-white py-2 rounded-lg">Join Project</button>
              ` : `
                <button onclick="toggleLogin()" class="mt-4 w-full btn-primary text-white py-2 rounded-lg">Login to Join</button>
              `}
            `;
            container.appendChild(card);
          });
        })
        .catch(err => console.error("Failed to load projects:", err));
    }
    function deleteProject(projectId) {
      if (!confirm("Are you sure you want to delete this project?")) return;
    
      firebase.firestore().collection('projects').doc(projectId).delete()
        .then(() => {
          alert("Project deleted.");
          renderProjects();
        })
        .catch(err => {
          console.error("Delete error:", err);
          alert("Failed to delete project.");
        });
    }
    function joinProject(projectId) {
      if (!currentUser) {
        alert("Login first");
        return;
      }
    
      const role = prompt("Your role in this project?");
      if (!role) return;
    
      const member = {
        userId: currentUser.id,
        username: currentUser.username,
        name: currentUser.name,
        role
      };
    
      const projectRef = firebase.firestore().collection("projects").doc(projectId);
      projectRef.update({
        members: firebase.firestore.FieldValue.arrayUnion(member)
      }).then(() => {
        alert("Joined the project.");
        renderProjects();
      }).catch(console.error);
    }
    
    function leaveProject(projectId) {
      if (!currentUser) return;
    
      const member = {
        userId: currentUser.id,
        username: currentUser.username,
        name: currentUser.name,
        role: ""
      };
    
      const projectRef = firebase.firestore().collection("projects").doc(projectId);
      projectRef.get().then(doc => {
        const project = doc.data();
        const updatedMembers = project.members.filter(m => m.userId !== currentUser.id);
        projectRef.update({ members: updatedMembers }).then(() => {
          alert("You left the project.");
          renderProjects();
        });
      });
    }
    
            

    function toggleCreateAnnouncement() {
      if (!currentUser) {
        alert('Please login to create an announcement.');
        toggleLogin();
        return;
      }
      document.getElementById('create-announcement').classList.toggle('hidden');
    }

    function submitAnnouncement() {
      const title = document.getElementById('announcement-title').value.trim();
      const content = document.getElementById('announcement-content').value.trim();
      
      if (!title || !content) {
        alert('Please fill in both title and content.');
        return;
      }
      
      const today = new Date();
      const dateString = today.toISOString().split('T')[0];
      
      const newAnnouncement = {
        id: announcements.length + 1,
        title,
        content,
        author: currentUser.username,
        date: dateString
      };
      
      announcements.unshift(newAnnouncement);
      renderAnnouncements();
      toggleCreateAnnouncement();
      
      // Reset form
      document.getElementById('announcement-title').value = '';
      document.getElementById('announcement-content').value = '';
    }

    function deleteAnnouncement(announcementId) {
      if (confirm('Are you sure you want to delete this announcement?')) {
        const index = announcements.findIndex(a => a.id === announcementId);
        if (index !== -1) {
          announcements.splice(index, 1);
          renderAnnouncements();
        }
      }
    }

    function logout() {
      firebase.auth().signOut().then(() => {
        currentUser = null;
        updateAuthUI();
        renderProjects();
        renderProfiles();
        renderAnnouncements();
        document.getElementById('profile-menu').classList.add('hidden');
      });
    }

    function viewProfile(username) {
      firebase.firestore().collection("users")
        .where("username", "==", username)
        .limit(1)
        .get()
        .then(snapshot => {
          if (snapshot.empty) {
            alert("User not found.");
            return;
          }
    
          const user = snapshot.docs[0].data();
          alert(`Viewing profile of ${user.name || user.username}\n\nBio: ${user.bio || 'Not provided'}\nFaculty: ${user.faculty || 'Not specified'}\nYear: ${user.year || 'Not specified'}`);
        })
        .catch(err => {
          console.error("Error viewing profile:", err);
        });
    }

    // Close dropdowns when clicking outside
    document.addEventListener('click', function(event) {
      if (!event.target.closest('#profile-menu') && !event.target.closest('#user-info')) {
        document.getElementById('profile-menu').classList.add('hidden');
      }
    });


// --- UI AUTH STATE ---
function updateAuthUI() {
  const authButtons = document.getElementById("auth-buttons");
  const userInfo = document.getElementById("user-info");
  if (currentUser) {
    authButtons.classList.add("hidden");
    userInfo.classList.remove("hidden");
    document.getElementById("header-username").innerText = currentUser.username || currentUser.email;
    document.getElementById("header-user-avatar").src = currentUser.avatar || "default-avatar.png";
  } else {
    authButtons.classList.remove("hidden");
    userInfo.classList.add("hidden");
  }
}

// --- REGISTER ---
async function submitRegister() {
  const username = document.getElementById('reg-username').value.trim();
  const email = document.getElementById('reg-email').value.trim();
  const password = document.getElementById('reg-password').value.trim();

  if (username.length < 4 || password.length < 6 || !email.includes('@')) {
    alert('Check input fields: username >= 4 chars, password >= 6 chars, valid email.');
    return;
  }

  try {
    const usersRef = firebase.firestore().collection('users');
    const querySnapshot = await usersRef
      .where('username', '==', username)
      .get();

    if (!querySnapshot.empty) {
      alert('This username is already taken.');
      return;
    }

    const emailSnapshot = await usersRef.where('email', '==', email).get();
    if (!emailSnapshot.empty) {
      alert('This email is already registered.');
      return;
    }

    const userCred = await firebase.auth().createUserWithEmailAndPassword(email, password);
    const uid = userCred.user.uid;

    const newUser = {
      username,
      email,
      name: username,
      bio: '',
      faculty: '',
      year: '',
      skills: [],
      avatar: '',
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    };

    await firebase.firestore().collection('users').doc(uid).set(newUser);

    currentUser = { ...newUser, id: uid };
    updateAuthUI();
    renderProfiles();
    toggleRegister();
    alert(`Welcome to TeamUp, ${username}!`);
    openProfileModal();
  } catch (error) {
    console.error("Registration error:", error);
    alert("Registration failed: " + error.message);
  }
}


// --- LOGIN ---
function submitLogin() {
  const email = document.getElementById("login-email").value.trim();
  const password = document.getElementById("login-password").value.trim();

  firebase.auth().signInWithEmailAndPassword(email, password)
    .then(async (userCredential) => {
      const uid = userCredential.user.uid;
      const doc = await firebase.firestore().collection("users").doc(uid).get();
      if (!doc.exists) return alert("User profile not found.");
      currentUser = doc.data();
      currentUser.id = uid;
      updateAuthUI();
      renderProjects();
      renderProfiles();
      renderAnnouncements();
      toggleLogin();
    })
    .catch(err => alert("Login failed: " + err.message));
}

// --- POST CREATION WITH MODERATION ---
async function submitPost() {
  const title = document.getElementById("post-title").value.trim();
  const description = document.getElementById("post-description").value.trim();
  const tags = document.getElementById("post-tags").value.trim().split(",").map(t => t.trim());

  if (!title || !description) {
    alert("Fill in all required fields.");
    return;
  }

  // Moderation via GPT-4o (must be implemented on Cloud Function)
  const modResponse = await fetch('/moderate', {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ title, description })
  });
  const result = await modResponse.json();
  if (!result.ok) {
    alert("Post was flagged and not submitted.");
    return;
  }

  firebase.firestore().collection("posts").add({
    title,
    description,
    tags,
    author: currentUser.username,
    userId: currentUser.id,
    createdAt: firebase.firestore.FieldValue.serverTimestamp()
  }).then(() => {
    alert("Post added!");
    document.getElementById("post-form").reset();
    renderProjects();
  });
}

// --- COMMENT CREATION WITH MODERATION ---
async function submitComment(postId, commentText) {
  if (!commentText || !postId) return;
  const mod = await fetch("/moderate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ text: commentText })
  });
  const res = await mod.json();
  if (!res.ok) {
    alert("Comment rejected by moderation.");
    return;
  }

  firebase.firestore().collection("posts").doc(postId).collection("comments").add({
    text: commentText,
    author: currentUser.username,
    userId: currentUser.id,
    createdAt: firebase.firestore.FieldValue.serverTimestamp()
  }).then(() => {
    alert("Comment posted.");
    renderPostComments(postId);
  });
}

// --- PROFILE REDIRECT ---
function goToProfile() {
  if (!currentUser) return;
  window.location.href = `/Profile/index.html?uid=${currentUser.id}`;
}

// --- TOGGLE FORMS ---
window.toggleLogin = function() {
  const loginModal = document.getElementById('login');
  loginModal.classList.toggle('hidden');
};

window.toggleRegister = function() {
  const registerModal = document.getElementById('register');
  registerModal.classList.toggle('hidden');
};

function deletePost(postId) {
  if (!currentUser) {
    alert("You must be logged in to delete a post.");
    return;
  }

  const postRef = firebase.firestore().collection('posts').doc(postId);

  postRef.get().then(doc => {
    if (!doc.exists) {
      alert("Post not found.");
      return;
    }

    const postData = doc.data();
    if (postData.authorId !== currentUser.id) {
      alert("You can only delete your own posts.");
      return;
    }

    if (!confirm("Are you sure you want to delete this post?")) return;


    firebase.firestore().collection('comments')
      .where('postId', '==', postId)
      .get()
      .then(snapshot => {
        const batch = firebase.firestore().batch();
        snapshot.forEach(doc => {
          batch.delete(doc.ref);
        });
        return batch.commit();
      })
      .then(() => postRef.delete())
      .then(() => {
        alert("Post deleted.");
        renderProjects();
      })
      .catch(err => {
        console.error("Delete error:", err);
        alert("Failed to delete post.");
      });
  }).catch(err => {
    console.error("Fetch error:", err);
    alert("Failed to find post.");
  });
}

function deleteComment(commentId, postId) {
  if (!currentUser) {
    alert("You must be logged in to delete comments.");
    return;
  }

  const commentRef = firebase.firestore().collection('comments').doc(commentId);

  commentRef.get()
    .then(doc => {
      if (!doc.exists) {
        alert("Comment not found.");
        return;
      }

      const data = doc.data();
      if (data.authorId !== currentUser.id) {
        alert("You can only delete your own comments.");
        return;
      }

      if (!confirm("Delete this comment?")) return;

      return commentRef.delete();
    })
    .then(() => {
      alert("Comment deleted.");
      renderComments(postId);
    })
    .catch(err => {
      console.error("Error deleting comment:", err);
      alert("Failed to delete comment.");
    });
}

function renderComments(postId) {
  const container = document.querySelector(`#comments-${postId}`);
  container.innerHTML = '';

  firebase.firestore().collection('comments')
    .where('postId', '==', postId)
    .orderBy('createdAt')
    .get()
    .then(snapshot => {
      snapshot.forEach(doc => {
        const comment = doc.data();
        const commentId = doc.id;

        const div = document.createElement('div');
        div.className = 'p-2 border-b';
        div.innerHTML = `
          <p class="text-sm text-gray-800">${comment.content}</p>
          ${comment.authorId === currentUser.id ? `
            <button onclick="deleteComment('${commentId}', '${postId}')" class="text-red-500 text-xs mt-1">Delete</button>
          ` : ''}
        `;
        container.appendChild(div);
      });
    });
}