const editToggleBtn = document.getElementById('editToggleBtn');
const profileName = document.getElementById('profileName');
const profileTitle = document.getElementById('profileTitle');
const avatarEditBtn = document.getElementById('avatarEditBtn');
const avatarUpload = document.getElementById('avatarUpload');
const profileAvatar = document.getElementById('profileAvatar');
const formInputs = document.querySelectorAll('.form-container input, .form-container textarea');

let isEditing = false;
let currentUID = null;

// Toggle Edit Mode
editToggleBtn.addEventListener('click', async () => {
  isEditing = !isEditing;

  if (isEditing) {
    editToggleBtn.innerHTML = '<i class="fas fa-check">Done</i>';
    profileName.contentEditable = 'true';
    profileTitle.contentEditable = 'true';
    profileName.classList.add('editable');
    profileTitle.classList.add('editable');

    formInputs.forEach(input => {
      input.readOnly = false;
      input.disabled = false;
    });

  } else {
    editToggleBtn.innerHTML = '<i class="fas fa-pen"></i>';
    profileName.contentEditable = 'false';
    profileTitle.contentEditable = 'false';
    profileName.classList.remove('editable');
    profileTitle.classList.remove('editable');

    formInputs.forEach(input => {
      input.readOnly = true;
    });

    // Save to Firestore
    if (currentUID) {
      await firebase.firestore().collection('users').doc(currentUID).update({
        name: profileName.textContent,
        title: profileTitle.textContent,
        username: document.getElementById('profile-username').value,
        email: document.getElementById('profile-email').value,
        bio: document.getElementById('profile-bio').value,
        faculty: document.getElementById('profile-faculty').value,
        year: document.getElementById('profile-year').value,
        avatar: profileAvatar.src
      });
      alert("Profile updated!");
    }
  }
});

// Avatar upload
avatarEditBtn.addEventListener('click', () => {
  avatarUpload.click();
});

avatarUpload.addEventListener('change', (e) => {
  if (e.target.files && e.target.files[0]) {
    const reader = new FileReader();
    reader.onload = function(event) {
      profileAvatar.src = event.target.result;
    }
    reader.readAsDataURL(e.target.files[0]);
  }
});

// Load profile data from Firestore
firebase.auth().onAuthStateChanged(async (user) => {
  if (user) {
    currentUID = user.uid;
    const doc = await firebase.firestore().collection("users").doc(user.uid).get();
    if (doc.exists) {
      const profile = doc.data();
      profileName.textContent = profile.name || '';
      profileTitle.textContent = profile.title || '';
      document.getElementById('profile-username').value = profile.username || '';
      document.getElementById('profile-email').value = profile.email || '';
      document.getElementById('profile-bio').value = profile.bio || '';
      document.getElementById('profile-faculty').value = profile.faculty || '';
      document.getElementById('profile-year').value = profile.year || '';
      if (profile.avatar) profileAvatar.src = profile.avatar;
    }
  } else {
    alert('Please log in to view your profile.');
    window.location.href = 'index.html';
  }
});

// Lock fields by default
formInputs.forEach(input => {
  input.readOnly = true;
});
function goHome() {
    window.location.href = "/index.html";
  }  
